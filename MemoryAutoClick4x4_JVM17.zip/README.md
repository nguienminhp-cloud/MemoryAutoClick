# Memory Auto Click 4x4

Bản Android dùng Accessibility Service + screenshot để đọc bàn 4x4 và tự bấm các cặp.

Cách dùng: mở app -> bật Accessibility -> trong game để 16 ô đang hiện hình -> bấm BẮT ĐẦU TỰ CLICK.

Lưu ý: vị trí bàn được suy ra theo tỉ lệ màn hình của video mẫu; game có bố cục khác có thể cần chỉnh tọa độ.
