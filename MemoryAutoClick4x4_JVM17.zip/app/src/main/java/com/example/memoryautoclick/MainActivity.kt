package com.example.memoryautoclick

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        val title = TextView(this).apply { text = "Memory Auto Click 4×4"; textSize = 24f }
        status = TextView(this).apply { textSize = 16f; setPadding(0,20,0,20) }
        val open = Button(this).apply { text = "1. Mở quyền Accessibility"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val start = Button(this).apply { text = "2. BẮT ĐẦU TỰ CLICK"; setOnClickListener {
            MemoryAccessibilityService.command = MemoryAccessibilityService.Command.START
            status.text = "Đã gửi lệnh bắt đầu. Mở game và để màn hình 16 ô đang hiện hình."
        }}
        val stop = Button(this).apply { text = "DỪNG"; setOnClickListener {
            MemoryAccessibilityService.command = MemoryAccessibilityService.Command.STOP
            status.text = "Đã dừng."
        }}
        val info = TextView(this).apply {
            text = "Mặc định theo video: 1080×2340, bàn 4×4.\nNếu máy khác tỉ lệ màn hình, service tự co giãn theo kích thước màn hình.\nKhông cần root."
            textSize = 15f; setPadding(0,30,0,0)
        }
        root.addView(title); root.addView(status); root.addView(open); root.addView(start); root.addView(stop); root.addView(info)
        setContentView(root)
    }
}
