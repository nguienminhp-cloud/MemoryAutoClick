package com.example.memoryautoclick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.hardware.HardwareBuffer
import android.graphics.Bitmap.Config
import android.graphics.Color
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.sqrt

class MemoryAccessibilityService : AccessibilityService() {
    enum class Command { NONE, START, STOP }
    companion object { @Volatile var command = Command.NONE }

    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val busy = AtomicBoolean(false)
    private var lastCommand = Command.NONE

    override fun onServiceConnected() {
        super.onServiceConnected()
        main.post(poll)
    }

    private val poll = object : Runnable {
        override fun run() {
            when (command) {
                Command.START -> if (lastCommand != Command.START) startGame()
                Command.STOP -> if (lastCommand != Command.STOP) stopGame()
                else -> {}
            }
            lastCommand = command
            main.postDelayed(this, 150)
        }
    }

    private fun startGame() {
        if (running.get()) return
        running.set(true); busy.set(true)
        // Video shows the 16 cards face-up first. Capture immediately.
        main.postDelayed({ captureBoardAndPlay() }, 300)
    }

    private fun stopGame() { running.set(false); busy.set(false); main.removeCallbacksAndMessages(null); main.post(poll) }

    private fun captureBoardAndPlay() {
        if (!running.get()) return
        takeScreenshot(0, Executor { command -> main.post(command) }, object : TakeScreenshotCallback() {
            override fun onSuccess(screenshot: ScreenshotResult) {
                try {
                    val hw = screenshot.hardwareBuffer
                    val bmp0 = Bitmap.wrapHardwareBuffer(hw, screenshot.colorSpace) ?: throw IllegalStateException("No screenshot bitmap")
                    val bmp = bmp0.copy(Config.ARGB_8888, false)
                    hw.close()
                    val pairs = recognizePairs(bmp)
                    bmp.recycle()
                    if (pairs.size != 8) { running.set(false); return }
                    // Wait for the game's initial preview to end, then reveal each known pair.
                    main.postDelayed({ playPairs(pairs, 0) }, 1800)
                } catch (_: Throwable) { running.set(false) }
            }
            override fun onFailure(errorCode: Int) { running.set(false) }
        }, main)
    }

    private fun playPairs(pairs: List<Pair<Int,Int>>, index: Int) {
        if (!running.get() || index >= pairs.size) { running.set(false); busy.set(false); return }
        val (a,b) = pairs[index]
        val p1 = centerFor(a); val p2 = centerFor(b)
        tap(p1.first,p1.second) {
            main.postDelayed({
                tap(p2.first,p2.second) {
                    // Allow the game to remove the matched cards before next pair.
                    main.postDelayed({ playPairs(pairs,index+1) }, 420)
                }
            }, 180)
        }
    }

    private fun tap(x: Float, y: Float, done: () -> Unit) {
        val path = Path().apply { moveTo(x,y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,55)).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (running.get()) main.postDelayed(done,100) }
        }, main)
    }

    // Coordinates are proportional to screen size. Default matches the supplied 1080×2340 video:
    // board roughly x=100..980, y=930..1700.
    private fun centerFor(i: Int): Pair<Float,Float> {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val left = w * 0.094f; val right = w * 0.906f
        val top = h * 0.397f; val bottom = h * 0.724f
        val col = i % 4; val row = i / 4
        return Pair(left + (right-left)*(col+0.5f)/4f, top + (bottom-top)*(row+0.5f)/4f)
    }

    private fun recognizePairs(screen: Bitmap): List<Pair<Int,Int>> {
        val cells = ArrayList<Cell>(16)
        val w = screen.width.toFloat(); val h = screen.height.toFloat()
        val left = (w*0.094f).toInt(); val right = (w*0.906f).toInt()
        val top = (h*0.397f).toInt(); val bottom = (h*0.724f).toInt()
        val cw = (right-left)/4; val ch=(bottom-top)/4
        for (i in 0 until 16) {
            val col=i%4; val row=i/4
            val x=left+col*cw; val y=top+row*ch
            val padX=(cw*0.18f).toInt(); val padY=(ch*0.18f).toInt()
            val crop=Bitmap.createBitmap(screen, x+padX, y+padY, cw-2*padX, ch-2*padY)
            cells.add(Cell(i, signature(crop))); crop.recycle()
        }
        // Greedy matching: for each card choose its closest unused partner.
        val unused=cells.toMutableList(); val out=ArrayList<Pair<Int,Int>>()
        while(unused.isNotEmpty()) {
            val a=unused.removeAt(0)
            var bestIdx=0; var best=Float.MAX_VALUE
            for (j in unused.indices) { val d=distance(a.sig,unused[j].sig); if(d<best){best=d;bestIdx=j} }
            val b=unused.removeAt(bestIdx); out.add(Pair(a.index,b.index))
        }
        return out
    }

    private data class Cell(val index:Int,val sig:FloatArray)

    // 16×16 grayscale + RGB means. Same card at two positions produces nearly the same signature.
    private fun signature(b: Bitmap): FloatArray {
        val out=FloatArray(16*16+3); var k=0; var sr=0f;var sg=0f;var sb=0f;var n=0
        for(y in 0 until 16) for(x in 0 until 16) {
            val sx=x*b.width/16; val sy=y*b.height/16; val c=b.getPixel(sx,sy)
            val r=Color.red(c)/255f;val g=Color.green(c)/255f;val bl=Color.blue(c)/255f
            out[k++]=0.299f*r+0.587f*g+0.114f*bl; sr+=r;sg+=g;sb+=bl;n++
        }
        out[k++]=sr/n;out[k++]=sg/n;out[k]=sb/n; return out
    }
    private fun distance(a:FloatArray,b:FloatArray):Float {
        var s=0f; for(i in a.indices){ val d=a[i]-b[i]; s+=d*d }; return sqrt(s/a.size)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopGame() }
}
